'use client';

import React from 'react';

export default function Page() {
  return (
    <div style={{
      fontFamily: 'Arial, sans-serif',
      minHeight: '100vh',
      background: 'linear-gradient(to right, #0f2027, #203a43, #2c5364)',
      color: 'white',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      fontSize: '2rem'
    }}>
      <div>Hello from Dashboard</div>
    </div>
  );
}
