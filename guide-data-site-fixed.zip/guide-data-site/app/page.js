'use client';

import React from 'react';

export default function Page() {
  return (
    <div style={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      height: '100vh',
      fontSize: '2rem'
    }}>
      Welcome to the Smart Data Guide!
    </div>
  );
}
